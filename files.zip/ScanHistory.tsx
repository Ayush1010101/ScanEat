import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { useLocation } from "wouter";
import { ArrowLeft, Trash2, Grid3x3, List, Loader2, Dumbbell } from "lucide-react";
import { toast } from "sonner";
import { format } from "date-fns";

export default function ScanHistory() {
  const [, navigate] = useLocation();
  const [viewMode, setViewMode] = useState<"grid" | "list">("grid");
  const [selectedScans, setSelectedScans] = useState<number[]>([]);

  const { data: scans, isLoading, refetch } = trpc.food.getScanHistory.useQuery();
  const deleteScanMutation = trpc.food.deleteScan.useMutation({
    onSuccess: () => { toast.success("Scan deleted"); refetch(); },
    onError: (error: any) => toast.error(error.message || "Failed to delete scan"),
  });

  const handleDeleteScan = (scanId: number) => {
    if (window.confirm("Delete this scan?")) deleteScanMutation.mutate({ id: String(scanId) });
  };

  const handleSelectScan = (scanId: number) =>
    setSelectedScans((prev) => prev.includes(scanId) ? prev.filter((id) => id !== scanId) : [...prev, scanId]);

  const handleDeleteSelected = () => {
    if (!selectedScans.length) { toast.error("Select scans to delete"); return; }
    if (window.confirm(`Delete ${selectedScans.length} scan(s)?`)) {
      selectedScans.forEach((id) => deleteScanMutation.mutate({ id: String(id) }));
      setSelectedScans([]);
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-[#06061A]">
        <div className="text-center">
          <Loader2 className="w-12 h-12 animate-spin mx-auto mb-4 text-violet-400" />
          <p className="text-slate-400 text-sm tracking-wide">Loading your scans...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen pb-24 bg-[#06061A] relative">
      <div className="fixed top-0 left-1/2 -translate-x-1/2 w-[500px] h-48 bg-violet-700/8 rounded-full blur-3xl pointer-events-none" />

      {/* Header */}
      <div className="sticky top-0 z-40 bg-[#06061A]/85 backdrop-blur-xl border-b border-violet-500/10">
        <div className="max-w-6xl mx-auto px-4 py-4">
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-3">
              <button
                onClick={() => navigate("/")}
                className="w-9 h-9 rounded-xl bg-[#101027] border border-violet-500/15 flex items-center justify-center hover:border-violet-500/40 hover:bg-violet-500/10 transition-all text-slate-400 hover:text-violet-400"
              >
                <ArrowLeft className="w-4 h-4" />
              </button>
              <div className="flex items-center gap-2">
                <div className="w-7 h-7 rounded-lg bg-gradient-to-br from-cyan-500 to-teal-600 flex items-center justify-center">
                  <Dumbbell className="w-4 h-4 text-white" />
                </div>
                <h1 className="text-xl font-bold text-white" style={{ fontFamily: "Syne, sans-serif" }}>Scan History</h1>
              </div>
            </div>
            {/* View toggles */}
            <div className="flex items-center gap-1 bg-[#101027] border border-violet-500/15 rounded-xl p-1">
              <button
                onClick={() => setViewMode("grid")}
                className={`p-2 rounded-lg transition-all ${viewMode === "grid" ? "bg-violet-600 text-white shadow-[0_0_10px_rgba(139,92,246,0.4)]" : "text-slate-400 hover:text-slate-200"}`}
              >
                <Grid3x3 className="w-4 h-4" />
              </button>
              <button
                onClick={() => setViewMode("list")}
                className={`p-2 rounded-lg transition-all ${viewMode === "list" ? "bg-violet-600 text-white shadow-[0_0_10px_rgba(139,92,246,0.4)]" : "text-slate-400 hover:text-slate-200"}`}
              >
                <List className="w-4 h-4" />
              </button>
            </div>
          </div>

          <div className="flex items-center justify-between">
            <p className="text-slate-400 text-sm">
              <span className="text-violet-300 font-bold">{scans?.length || 0}</span> total scans
            </p>
            {selectedScans.length > 0 && (
              <button
                onClick={handleDeleteSelected}
                className="px-4 py-1.5 bg-red-500/15 border border-red-500/30 text-red-400 hover:bg-red-500/25 rounded-xl text-sm font-semibold transition-all flex items-center gap-2"
              >
                <Trash2 className="w-3.5 h-3.5" />
                Delete {selectedScans.length}
              </button>
            )}
          </div>
        </div>
      </div>

      <div className="max-w-6xl mx-auto px-4 py-6 relative z-10">
        {!scans || scans.length === 0 ? (
          <div className="rounded-2xl p-10 text-center bg-[#0d0b22] border border-violet-500/10">
            <div className="w-16 h-16 mx-auto mb-4 rounded-2xl bg-violet-500/10 border border-violet-500/20 flex items-center justify-center">
              <span className="text-3xl">📭</span>
            </div>
            <h2 className="text-2xl font-bold text-white mb-2" style={{ fontFamily: "Syne, sans-serif" }}>No Scans Yet</h2>
            <p className="text-slate-400 text-sm mb-5">Start scanning food to build your nutrition history</p>
            <button
              onClick={() => navigate("/scanner")}
              className="px-6 py-2.5 bg-gradient-to-r from-violet-600 to-purple-600 hover:from-violet-500 hover:to-purple-500 text-white font-bold rounded-xl text-sm transition-all shadow-[0_0_20px_rgba(139,92,246,0.25)]"
            >
              Scan Your First Food
            </button>
          </div>
        ) : viewMode === "grid" ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {scans.map((scan: any) => (
              <div
                key={scan.id}
                onClick={() => handleSelectScan(scan.id)}
                className={`rounded-2xl overflow-hidden cursor-pointer transition-all duration-300 hover:scale-[1.02] border ${
                  selectedScans.includes(scan.id)
                    ? "ring-2 ring-violet-500 border-violet-500/50 bg-violet-500/10"
                    : "border-violet-500/10 bg-[#0d0b22] hover:border-violet-500/30 hover:bg-violet-500/5"
                }`}
              >
                {scan.imageUrl ? (
                  <img src={scan.imageUrl} alt={scan.foodName} className="w-full h-44 object-cover" />
                ) : (
                  <div className="w-full h-44 bg-gradient-to-br from-violet-700/30 to-purple-800/30 flex items-center justify-center text-4xl">🍽️</div>
                )}
                <div className="p-4">
                  <h3 className="font-bold text-white mb-1 text-sm" style={{ fontFamily: "Syne, sans-serif" }}>{scan.foodName}</h3>
                  <div className="flex items-center gap-2 mb-3">
                    <span className="text-amber-400 text-xs font-semibold">{Number(scan.calories)} kcal</span>
                    <span className="text-slate-600">·</span>
                    <span className="text-slate-500 text-xs">{format(new Date(scan.createdAt), "MMM d")}</span>
                  </div>
                  <button
                    onClick={(e) => { e.stopPropagation(); handleDeleteScan(scan.id); }}
                    className="w-full px-3 py-1.5 bg-red-500/10 border border-red-500/20 hover:bg-red-500/20 text-red-400 rounded-lg text-xs font-semibold transition-all flex items-center justify-center gap-1.5"
                  >
                    <Trash2 className="w-3.5 h-3.5" /> Delete
                  </button>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="space-y-3">
            {scans.map((scan: any) => (
              <div
                key={scan.id}
                onClick={() => handleSelectScan(scan.id)}
                className={`rounded-2xl p-4 cursor-pointer transition-all border ${
                  selectedScans.includes(scan.id)
                    ? "ring-2 ring-violet-500 border-violet-500/50 bg-violet-500/10"
                    : "border-violet-500/10 bg-[#0d0b22] hover:border-violet-500/25 hover:bg-violet-500/5"
                }`}
              >
                <div className="flex items-center justify-between gap-4">
                  <div className="flex items-center gap-3 flex-1 min-w-0">
                    {scan.imageUrl ? (
                      <img src={scan.imageUrl} alt={scan.foodName} className="w-14 h-14 rounded-xl object-cover flex-shrink-0 border border-violet-500/15" />
                    ) : (
                      <div className="w-14 h-14 rounded-xl bg-gradient-to-br from-violet-700/30 to-purple-800/30 border border-violet-500/15 flex items-center justify-center text-2xl flex-shrink-0">🍽️</div>
                    )}
                    <div className="flex-1 min-w-0">
                      <h3 className="font-bold text-white truncate text-sm" style={{ fontFamily: "Syne, sans-serif" }}>{scan.foodName}</h3>
                      <p className="text-slate-500 text-xs mt-0.5">
                        <span className="text-amber-400 font-semibold">{Number(scan.calories)} kcal</span>
                        {" · "}
                        {format(new Date(scan.createdAt), "MMM d, yyyy")}
                      </p>
                      {scan.foodType && (
                        <span className="text-xs px-2 py-0.5 rounded-full bg-violet-500/15 text-violet-300 border border-violet-500/20 mt-1 inline-block">
                          {String(scan.foodType)}
                        </span>
                      )}
                    </div>
                  </div>
                  <div className="flex items-center gap-2 flex-shrink-0">
                    <button
                      onClick={() => navigate(`/scan/${scan.id}`)}
                      className="px-3 py-1.5 bg-violet-600/20 border border-violet-500/25 hover:bg-violet-600/30 text-violet-300 rounded-lg text-xs font-semibold transition-all"
                    >
                      View
                    </button>
                    <button
                      onClick={(e) => { e.stopPropagation(); handleDeleteScan(scan.id); }}
                      className="p-2 bg-red-500/10 border border-red-500/15 hover:bg-red-500/20 text-red-400 rounded-lg transition-all"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
