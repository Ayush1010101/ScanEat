import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { useLocation } from "wouter";
import { Camera, Clock, Crown, Settings, Dumbbell, Flame, Zap, Activity } from "lucide-react";
import { getLoginUrl } from "@/const";

export default function Home() {
  const { user, loading } = useAuth();
  const [, setLocation] = useLocation();

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-[#06061A]">
        <div className="text-center">
          <div className="w-14 h-14 rounded-full border-2 border-violet-500/30 border-t-violet-400 animate-spin mx-auto mb-4" />
          <p className="text-slate-400 font-medium tracking-wide text-sm uppercase">Loading...</p>
        </div>
      </div>
    );
  }

  if (!user) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center p-6 bg-[#06061A] relative overflow-hidden">
        <div className="absolute top-1/4 left-1/2 -translate-x-1/2 w-96 h-96 bg-violet-600/10 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute bottom-1/4 left-1/4 w-64 h-64 bg-emerald-500/6 rounded-full blur-3xl pointer-events-none" />

        <div className="text-center max-w-sm relative z-10">
          <div className="w-24 h-24 mx-auto mb-6 rounded-2xl bg-gradient-to-br from-violet-600 to-purple-700 flex items-center justify-center shadow-[0_0_40px_rgba(139,92,246,0.4)]">
            <Dumbbell className="w-12 h-12 text-white" />
          </div>
          <h1 className="text-5xl font-bold mb-2 text-white" style={{ fontFamily: "Syne, sans-serif" }}>
            ScanEat
          </h1>
          <p className="text-violet-400 font-semibold tracking-widest text-xs uppercase mb-3">
            Nutrition Intelligence
          </p>
          <p className="text-slate-400 mb-10 leading-relaxed">
            Scan any food. Unlock macros, vitamins, health scores, and personalized insights — powered by AI.
          </p>
          <a href={getLoginUrl()}>
            <Button className="w-full bg-gradient-to-r from-violet-600 to-purple-600 hover:from-violet-500 hover:to-purple-500 text-white font-bold py-4 rounded-xl text-base tracking-wide shadow-[0_0_30px_rgba(139,92,246,0.3)] transition-all duration-300 hover:scale-[1.02]">
              Get Started
            </Button>
          </a>
          <div className="mt-8 flex items-center justify-center gap-6 text-slate-500 text-xs">
            <span className="flex items-center gap-1.5"><Flame className="w-3.5 h-3.5 text-amber-400" /> Calories</span>
            <span className="flex items-center gap-1.5"><Zap className="w-3.5 h-3.5 text-violet-400" /> Macros</span>
            <span className="flex items-center gap-1.5"><Activity className="w-3.5 h-3.5 text-emerald-400" /> Health Score</span>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen pb-24 bg-[#06061A] relative">
      <div className="fixed top-0 left-1/2 -translate-x-1/2 w-[600px] h-64 bg-violet-700/8 rounded-full blur-3xl pointer-events-none" />
      <div className="fixed bottom-1/3 right-0 w-72 h-72 bg-emerald-500/5 rounded-full blur-3xl pointer-events-none" />

      {/* Header */}
      <div className="sticky top-0 z-40 bg-[#06061A]/85 backdrop-blur-xl border-b border-violet-500/10">
        <div className="max-w-6xl mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-violet-600 to-purple-700 flex items-center justify-center">
              <Dumbbell className="w-5 h-5 text-white" />
            </div>
            <h1 className="text-xl font-bold text-white" style={{ fontFamily: "Syne, sans-serif" }}>
              ScanEat
            </h1>
          </div>
          <button
            onClick={() => setLocation("/profile")}
            className="w-9 h-9 rounded-xl bg-[#101027] border border-violet-500/15 flex items-center justify-center hover:border-violet-500/40 hover:bg-violet-500/10 transition-all text-slate-400 hover:text-violet-400"
          >
            <Settings className="w-4 h-4" />
          </button>
        </div>
      </div>

      <div className="max-w-6xl mx-auto px-4 py-6 md:py-8 relative z-10">

        {/* Welcome Banner */}
        <div className="mb-6 rounded-2xl overflow-hidden relative bg-gradient-to-br from-violet-700/80 via-purple-800/70 to-[#0a081e] border border-violet-500/25">
          <div className="absolute top-0 right-0 w-48 h-48 bg-violet-500/10 rounded-full blur-2xl -translate-y-1/2 translate-x-1/4 pointer-events-none" />
          <div className="absolute bottom-0 left-1/3 w-32 h-32 bg-emerald-500/8 rounded-full blur-xl translate-y-1/2 pointer-events-none" />

          <div className="relative z-10 p-6 md:p-8">
            <p className="text-violet-300/70 text-xs font-semibold tracking-widest uppercase mb-1">Welcome back</p>
            <h2 className="text-3xl md:text-4xl font-bold text-white mb-1" style={{ fontFamily: "Syne, sans-serif" }}>
              {user.name} 💪
            </h2>
            <p className="text-slate-300/70 text-sm">Ready to track your nutrition today?</p>

            <div className="flex items-center gap-5 mt-5 pt-4 border-t border-white/10">
              <div className="flex items-center gap-2">
                <Flame className="w-4 h-4 text-amber-400" />
                <span className="text-slate-400 text-xs">Calories</span>
              </div>
              <div className="w-px h-4 bg-white/10" />
              <div className="flex items-center gap-2">
                <Activity className="w-4 h-4 text-emerald-400" />
                <span className="text-slate-400 text-xs">Health Score</span>
              </div>
              <div className="w-px h-4 bg-white/10" />
              <div className="flex items-center gap-2">
                <Zap className="w-4 h-4 text-violet-400" />
                <span className="text-slate-400 text-xs">AI Insights</span>
              </div>
            </div>
          </div>
        </div>

        {/* Quick Actions */}
        <div className="grid grid-cols-2 gap-3 md:gap-4 mb-6">
          <button
            onClick={() => setLocation("/scanner")}
            className="group rounded-2xl p-5 md:p-6 bg-[#0d0b22] border border-violet-500/15 hover:border-violet-500/45 hover:bg-violet-500/8 transition-all duration-300 hover:scale-[1.02] text-left"
          >
            <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-violet-600 to-purple-700 flex items-center justify-center mb-4 group-hover:shadow-[0_0_20px_rgba(139,92,246,0.45)] transition-all">
              <Camera className="w-6 h-6 text-white" />
            </div>
            <h3 className="font-bold text-white mb-1" style={{ fontFamily: "Syne, sans-serif" }}>Scan Food</h3>
            <p className="text-slate-500 text-xs">AI-powered analysis</p>
          </button>

          <button
            onClick={() => setLocation("/history")}
            className="group rounded-2xl p-5 md:p-6 bg-[#0d0b22] border border-cyan-500/15 hover:border-cyan-500/45 hover:bg-cyan-500/8 transition-all duration-300 hover:scale-[1.02] text-left"
          >
            <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-cyan-500 to-teal-600 flex items-center justify-center mb-4 group-hover:shadow-[0_0_20px_rgba(34,211,238,0.35)] transition-all">
              <Clock className="w-6 h-6 text-white" />
            </div>
            <h3 className="font-bold text-white mb-1" style={{ fontFamily: "Syne, sans-serif" }}>History</h3>
            <p className="text-slate-500 text-xs">View past scans</p>
          </button>

          <button
            onClick={() => setLocation("/premium")}
            className="group rounded-2xl p-5 md:p-6 bg-[#0d0b22] border border-amber-500/15 hover:border-amber-500/45 hover:bg-amber-500/6 transition-all duration-300 hover:scale-[1.02] text-left"
          >
            <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-amber-500 to-orange-600 flex items-center justify-center mb-4 group-hover:shadow-[0_0_20px_rgba(251,191,36,0.35)] transition-all">
              <Crown className="w-6 h-6 text-white" />
            </div>
            <h3 className="font-bold text-white mb-1" style={{ fontFamily: "Syne, sans-serif" }}>Premium</h3>
            <p className="text-slate-500 text-xs">Unlock features</p>
          </button>

          <button
            onClick={() => setLocation("/profile")}
            className="group rounded-2xl p-5 md:p-6 bg-[#0d0b22] border border-emerald-500/15 hover:border-emerald-500/45 hover:bg-emerald-500/6 transition-all duration-300 hover:scale-[1.02] text-left"
          >
            <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-emerald-500 to-teal-600 flex items-center justify-center mb-4 group-hover:shadow-[0_0_20px_rgba(16,185,129,0.35)] transition-all">
              <Settings className="w-6 h-6 text-white" />
            </div>
            <h3 className="font-bold text-white mb-1" style={{ fontFamily: "Syne, sans-serif" }}>Profile</h3>
            <p className="text-slate-500 text-xs">Your preferences</p>
          </button>
        </div>

        {/* Recent Scans */}
        <div>
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-bold text-white" style={{ fontFamily: "Syne, sans-serif" }}>Recent Scans</h3>
            <button onClick={() => setLocation("/history")} className="text-violet-400 text-xs font-semibold hover:text-violet-300 transition-colors tracking-wide">
              View All →
            </button>
          </div>
          <div className="rounded-2xl p-8 text-center bg-[#0d0b22] border border-violet-500/10">
            <div className="w-16 h-16 mx-auto mb-4 rounded-2xl bg-violet-500/10 border border-violet-500/20 flex items-center justify-center">
              <Camera className="w-7 h-7 text-violet-400/50" />
            </div>
            <p className="text-slate-500 text-sm mb-4">No scans yet — start by photographing your first meal!</p>
            <button
              onClick={() => setLocation("/scanner")}
              className="px-5 py-2 rounded-xl bg-violet-600/20 border border-violet-500/30 text-violet-300 text-sm font-semibold hover:bg-violet-600/30 transition-all"
            >
              Scan Now
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
