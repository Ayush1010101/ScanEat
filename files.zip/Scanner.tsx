import { useRef, useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Camera, Upload, X, Loader2, ArrowLeft, Dumbbell } from "lucide-react";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";
import { useLocation } from "wouter";

export default function Scanner() {
  const [, navigate] = useLocation();
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [cameraActive, setCameraActive] = useState(false);
  const [capturedImage, setCapturedImage] = useState<string | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);

  const analyzeFoodMutation = trpc.food.analyzeFood.useMutation({
    onSuccess: (data) => {
      setIsProcessing(false);
      navigate(`/scan/${data.id}`);
    },
    onError: (error) => {
      setIsProcessing(false);
      toast.error(error.message || "Failed to analyze food. Please try again.");
    },
  });

  useEffect(() => {
    if (!cameraActive) return;
    const startCamera = async () => {
      try {
        const stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: "environment" } });
        if (videoRef.current) videoRef.current.srcObject = stream;
      } catch {
        toast.error("Unable to access camera. Please check permissions.");
        setCameraActive(false);
      }
    };
    startCamera();
    return () => {
      if (videoRef.current?.srcObject) {
        (videoRef.current.srcObject as MediaStream).getTracks().forEach((t) => t.stop());
      }
    };
  }, [cameraActive]);

  const capturePhoto = () => {
    if (videoRef.current && canvasRef.current) {
      const ctx = canvasRef.current.getContext("2d");
      if (ctx) {
        canvasRef.current.width = videoRef.current.videoWidth;
        canvasRef.current.height = videoRef.current.videoHeight;
        ctx.drawImage(videoRef.current, 0, 0);
        setCapturedImage(canvasRef.current.toDataURL("image/jpeg"));
        setCameraActive(false);
      }
    }
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (ev) => setCapturedImage(ev.target?.result as string);
      reader.readAsDataURL(file);
    }
  };

  const handleAnalyze = async () => {
    if (!capturedImage) { toast.error("Please capture or upload an image first."); return; }
    setIsProcessing(true);
    try {
      analyzeFoodMutation.mutate({ imageData: capturedImage.split(",")[1] });
    } catch {
      setIsProcessing(false);
      toast.error("Failed to process image. Please try again.");
    }
  };

  return (
    <div className="min-h-screen pb-24 bg-[#06061A] relative">
      <div className="fixed top-0 left-1/2 -translate-x-1/2 w-[500px] h-48 bg-violet-700/8 rounded-full blur-3xl pointer-events-none" />

      {/* Header */}
      <div className="sticky top-0 z-40 bg-[#06061A]/85 backdrop-blur-xl border-b border-violet-500/10">
        <div className="max-w-6xl mx-auto px-4 py-4 flex items-center gap-4">
          <button
            onClick={() => navigate("/")}
            className="w-9 h-9 rounded-xl bg-[#101027] border border-violet-500/15 flex items-center justify-center hover:border-violet-500/40 hover:bg-violet-500/10 transition-all text-slate-400 hover:text-violet-400"
          >
            <ArrowLeft className="w-4 h-4" />
          </button>
          <div className="flex items-center gap-3">
            <div className="w-7 h-7 rounded-lg bg-gradient-to-br from-violet-600 to-purple-700 flex items-center justify-center">
              <Dumbbell className="w-4 h-4 text-white" />
            </div>
            <h1 className="text-xl font-bold text-white" style={{ fontFamily: "Syne, sans-serif" }}>Scan Food</h1>
          </div>
        </div>
      </div>

      <div className="max-w-2xl mx-auto px-4 py-6 relative z-10">
        {!capturedImage ? (
          <div className="space-y-5">
            {cameraActive ? (
              <div className="space-y-4">
                <div className="rounded-2xl overflow-hidden border border-violet-500/30 shadow-[0_0_30px_rgba(139,92,246,0.15)]">
                  <video ref={videoRef} autoPlay playsInline className="w-full h-auto bg-black" />
                </div>
                <div className="flex gap-3">
                  <Button
                    onClick={capturePhoto}
                    className="flex-1 bg-gradient-to-r from-violet-600 to-purple-600 hover:from-violet-500 hover:to-purple-500 text-white font-bold py-3 rounded-xl text-base shadow-[0_0_20px_rgba(139,92,246,0.3)] hover:shadow-[0_0_25px_rgba(139,92,246,0.5)] transition-all"
                  >
                    <Camera className="w-5 h-5 mr-2" />
                    Capture
                  </Button>
                  <Button
                    onClick={() => setCameraActive(false)}
                    variant="outline"
                    className="flex-1 border-violet-500/25 bg-[#101027] text-slate-300 hover:bg-violet-500/10 hover:border-violet-500/40 hover:text-white rounded-xl py-3 text-base"
                  >
                    <X className="w-5 h-5 mr-2" />
                    Cancel
                  </Button>
                </div>
              </div>
            ) : (
              <div className="rounded-2xl p-10 text-center border-2 border-dashed border-violet-500/20 bg-[#0d0b22] hover:border-violet-500/40 transition-all">
                {/* Decorative icon */}
                <div className="w-20 h-20 mx-auto mb-5 rounded-2xl bg-gradient-to-br from-violet-600/20 to-purple-700/20 border border-violet-500/25 flex items-center justify-center">
                  <Camera className="w-10 h-10 text-violet-400" />
                </div>
                <h2 className="text-2xl font-bold text-white mb-2" style={{ fontFamily: "Syne, sans-serif" }}>
                  Ready to Scan?
                </h2>
                <p className="text-slate-400 mb-7 text-sm leading-relaxed">
                  Take a photo or upload an image of your food and our AI will instantly analyze its nutritional content.
                </p>

                {/* Feature pills */}
                <div className="flex items-center justify-center gap-3 mb-7 flex-wrap">
                  {["Calories", "Macros", "Vitamins", "Health Score"].map((tag) => (
                    <span key={tag} className="px-3 py-1 rounded-full bg-violet-500/10 border border-violet-500/20 text-violet-300 text-xs font-medium">
                      {tag}
                    </span>
                  ))}
                </div>

                <div className="flex flex-col sm:flex-row gap-3">
                  <Button
                    onClick={() => setCameraActive(true)}
                    className="flex-1 bg-gradient-to-r from-violet-600 to-purple-600 hover:from-violet-500 hover:to-purple-500 text-white font-bold py-3 rounded-xl text-base shadow-[0_0_20px_rgba(139,92,246,0.25)] hover:shadow-[0_0_25px_rgba(139,92,246,0.45)] transition-all"
                  >
                    <Camera className="w-5 h-5 mr-2" />
                    Open Camera
                  </Button>
                  <Button
                    onClick={() => fileInputRef.current?.click()}
                    className="flex-1 bg-[#141430] hover:bg-violet-500/15 border border-violet-500/25 hover:border-violet-500/50 text-slate-200 hover:text-white font-bold py-3 rounded-xl text-base transition-all"
                  >
                    <Upload className="w-5 h-5 mr-2" />
                    Upload Image
                  </Button>
                </div>
                <input ref={fileInputRef} type="file" accept="image/*" onChange={handleFileUpload} className="hidden" />
              </div>
            )}
          </div>
        ) : (
          <div className="space-y-5">
            {/* Preview */}
            <div className="rounded-2xl overflow-hidden border border-violet-500/25 shadow-[0_0_30px_rgba(139,92,246,0.15)]">
              <img src={capturedImage} alt="Captured food" className="w-full h-auto" />
            </div>

            {/* Analysis Card */}
            <div className="rounded-2xl p-6 bg-[#0d0b22] border border-violet-500/20">
              <h3 className="text-lg font-bold text-white mb-2" style={{ fontFamily: "Syne, sans-serif" }}>
                Ready to Analyze?
              </h3>
              <p className="text-slate-400 text-sm mb-5 leading-relaxed">
                Our AI will identify your food and break down calories, macronutrients, vitamins, health score, and more.
              </p>

              <div className="flex flex-col sm:flex-row gap-3">
                <Button
                  onClick={handleAnalyze}
                  disabled={isProcessing}
                  className="flex-1 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-bold py-3 rounded-xl text-base shadow-[0_0_20px_rgba(16,185,129,0.25)] hover:shadow-[0_0_25px_rgba(16,185,129,0.45)] transition-all disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  {isProcessing ? (
                    <><Loader2 className="w-5 h-5 mr-2 animate-spin" />Analyzing...</>
                  ) : (
                    "Analyze Food"
                  )}
                </Button>
                <Button
                  onClick={() => setCapturedImage(null)}
                  className="flex-1 bg-[#141430] hover:bg-violet-500/15 border border-violet-500/25 hover:border-violet-500/50 text-slate-300 hover:text-white font-bold py-3 rounded-xl text-base transition-all"
                >
                  <X className="w-5 h-5 mr-2" />
                  Retake
                </Button>
              </div>
            </div>
          </div>
        )}
      </div>

      <canvas ref={canvasRef} className="hidden" />
    </div>
  );
}
