import { useAuth } from "@/_core/hooks/useAuth";
import { useLocation } from "wouter";
import { Home, Camera, History, Crown, Settings as SettingsIcon } from "lucide-react";

export default function BottomNavigation() {
  const [location, navigate] = useLocation();

  const navItems = [
    { path: "/", label: "Home", icon: Home, activeColor: "text-violet-400", activeBg: "bg-violet-500/15 border-violet-500/25" },
    { path: "/scanner", label: "Scan", icon: Camera, activeColor: "text-emerald-400", activeBg: "bg-emerald-500/15 border-emerald-500/25" },
    { path: "/history", label: "History", icon: History, activeColor: "text-cyan-400", activeBg: "bg-cyan-500/15 border-cyan-500/25" },
    { path: "/premium", label: "Premium", icon: Crown, activeColor: "text-amber-400", activeBg: "bg-amber-500/15 border-amber-500/25" },
  ];

  const isActive = (path: string) => location === path;

  return (
    <div className="fixed bottom-0 left-0 right-0 z-50">
      {/* Gradient fade */}
      <div className="absolute inset-x-0 -top-6 h-6 bg-gradient-to-t from-[#06061A] to-transparent pointer-events-none" />

      <div className="bg-[#06061A]/90 backdrop-blur-xl border-t border-violet-500/10">
        <div className="max-w-2xl mx-auto px-4 py-2 flex items-center justify-around">
          {navItems.map((item) => {
            const Icon = item.icon;
            const active = isActive(item.path);
            return (
              <button
                key={item.path}
                onClick={() => navigate(item.path)}
                className={`flex flex-col items-center justify-center py-2 px-4 rounded-xl transition-all duration-250 border ${
                  active
                    ? `${item.activeColor} ${item.activeBg}`
                    : "text-slate-500 border-transparent hover:text-slate-300 hover:bg-white/5"
                }`}
              >
                <Icon className="w-5 h-5 mb-0.5" />
                <span className="text-xs font-semibold">{item.label}</span>
              </button>
            );
          })}

          {/* Settings */}
          <button
            onClick={() => navigate("/settings")}
            className={`flex flex-col items-center justify-center py-2 px-4 rounded-xl transition-all duration-250 border ${
              isActive("/settings")
                ? "text-violet-400 bg-violet-500/15 border-violet-500/25"
                : "text-slate-500 border-transparent hover:text-slate-300 hover:bg-white/5"
            }`}
          >
            <SettingsIcon className="w-5 h-5 mb-0.5" />
            <span className="text-xs font-semibold">Settings</span>
          </button>
        </div>
      </div>
    </div>
  );
}
