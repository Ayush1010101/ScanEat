import { useRoute, useLocation } from "wouter";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { AlertCircle, ArrowLeft, Trash2, Flame, Droplets, Zap, Heart, Shield, Leaf, Utensils } from "lucide-react";
import { format } from "date-fns";
import { toast } from "sonner";

export default function ScanDetail() {
  const [, params] = useRoute("/scan/:id");
  const [, setLocation] = useLocation();
  const navigate = (path: string) => setLocation(path);
  const scanId = params?.id;

  const { data: scan, isLoading, error } = trpc.food.getScanDetail.useQuery(
    { id: scanId || "" },
    { enabled: !!scanId }
  );

  const deleteMutation = trpc.food.deleteScan.useMutation({
    onSuccess: () => { toast.success("Scan deleted"); navigate("/history"); },
    onError: (error) => toast.error(error.message || "Failed to delete scan"),
  });

  const baseClasses = "min-h-screen bg-[#06061A] py-8 px-4 pb-24";

  if (!scanId) return (
    <div className={baseClasses}>
      <div className="max-w-4xl mx-auto">
        <Button variant="ghost" onClick={() => navigate("/")} className="mb-6 text-violet-400 hover:bg-violet-500/10">
          <ArrowLeft className="w-4 h-4 mr-2" /> Back
        </Button>
        <p className="text-slate-400">Scan not found</p>
      </div>
    </div>
  );

  if (isLoading) return (
    <div className={`${baseClasses} flex items-center justify-center`}>
      <div className="text-center">
        <div className="w-12 h-12 rounded-full border-2 border-violet-500/30 border-t-violet-400 animate-spin mx-auto mb-4" />
        <p className="text-slate-400 text-sm">Analyzing nutrition data...</p>
      </div>
    </div>
  );

  if (error || !scan) return (
    <div className={baseClasses}>
      <div className="max-w-4xl mx-auto">
        <Button variant="ghost" onClick={() => navigate("/history")} className="mb-6 text-violet-400 hover:bg-violet-500/10">
          <ArrowLeft className="w-4 h-4 mr-2" /> Back
        </Button>
        <div className="bg-red-500/10 border border-red-500/25 rounded-2xl p-6">
          <div className="flex items-start gap-3">
            <AlertCircle className="w-5 h-5 text-red-400 flex-shrink-0 mt-0.5" />
            <div>
              <h2 className="font-bold text-red-300 mb-1">Error Loading Scan</h2>
              <p className="text-red-400 text-sm">{error?.message || "The scan could not be found"}</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );

  const healthScore = Number(scan.healthScore) || 0;
  const confidenceScore = Math.round(Number(scan.confidenceScore) * 100) || 0;
  const totalCalories = Number(scan.calories) || 0;
  const proteinCals = (Number(scan.protein) || 0) * 4;
  const carbsCals = (Number(scan.carbs) || 0) * 4;
  const fatsCals = (Number(scan.fats) || 0) * 9;
  const totalMacroCals = proteinCals + carbsCals + fatsCals;
  const proteinPercent = totalMacroCals > 0 ? (proteinCals / totalMacroCals) * 100 : 0;
  const carbsPercent = totalMacroCals > 0 ? (carbsCals / totalMacroCals) * 100 : 0;
  const fatsPercent = totalMacroCals > 0 ? (fatsCals / totalMacroCals) * 100 : 0;

  const getHealthColor = (score: number) => score >= 7 ? "text-emerald-400" : score >= 5 ? "text-amber-400" : "text-red-400";
  const getConfidenceBg = (score: number) => score >= 80 ? "border-emerald-500/25 bg-emerald-500/8" : score >= 60 ? "border-amber-500/25 bg-amber-500/8" : "border-red-500/25 bg-red-500/8";

  return (
    <div className={`${baseClasses} relative`}>
      {/* Ambient glows */}
      <div className="fixed top-0 left-1/2 -translate-x-1/2 w-[500px] h-48 bg-violet-700/8 rounded-full blur-3xl pointer-events-none" />
      <div className="fixed bottom-1/4 right-0 w-64 h-64 bg-emerald-500/5 rounded-full blur-3xl pointer-events-none" />

      <div className="max-w-6xl mx-auto relative z-10">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <Button
            variant="ghost"
            onClick={() => navigate("/history")}
            className="text-violet-400 hover:bg-violet-500/10 rounded-xl"
          >
            <ArrowLeft className="w-4 h-4 mr-2" /> Back
          </Button>
          <h1 className="text-2xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-violet-400 to-purple-400" style={{ fontFamily: "Syne, sans-serif" }}>
            Food Analysis
          </h1>
          <div className="w-20" />
        </div>

        <div className="grid lg:grid-cols-3 gap-5 mb-6">
          {/* Left Column */}
          <div className="lg:col-span-1 space-y-4">
            {scan.imageUrl && (
              <div className="rounded-2xl overflow-hidden border border-violet-500/20 shadow-[0_0_25px_rgba(139,92,246,0.12)]">
                <img src={scan.imageUrl} alt={scan.foodName} className="w-full h-56 object-cover" />
              </div>
            )}

            {/* Food Name */}
            <div className="bg-[#0d0b22] border border-violet-500/20 rounded-2xl p-5">
              <h2 className="text-xl font-bold text-white mb-3" style={{ fontFamily: "Syne, sans-serif" }}>{scan.foodName}</h2>
              <div className="flex gap-2 flex-wrap">
                <span className={`px-3 py-1 rounded-full text-xs font-semibold border ${
                  scan.isVegan === "true" ? "bg-emerald-500/15 text-emerald-300 border-emerald-500/25"
                  : scan.isVegetarian === "true" ? "bg-amber-500/15 text-amber-300 border-amber-500/25"
                  : "bg-violet-500/15 text-violet-300 border-violet-500/25"
                }`}>
                  {scan.isVegan === "true" ? "🌱 Vegan" : scan.isVegetarian === "true" ? "🥬 Vegetarian" : "🍗 Non-Veg"}
                </span>
                {scan.foodType && (
                  <span className="px-3 py-1 rounded-full text-xs font-semibold bg-cyan-500/15 text-cyan-300 border border-cyan-500/25">
                    {scan.foodType}
                  </span>
                )}
              </div>
            </div>

            {/* Date */}
            <div className="bg-[#0d0b22] border border-violet-500/15 rounded-2xl p-4 text-center">
              <p className="text-slate-500 text-xs mb-1">Scanned on</p>
              <p className="text-white font-semibold text-sm">{format(new Date(scan.createdAt), "MMM dd, yyyy HH:mm")}</p>
            </div>

            {/* AI Confidence */}
            {scan.confidenceScore && (
              <div className={`rounded-2xl border p-5 ${getConfidenceBg(confidenceScore)}`}>
                <div className="flex items-center gap-2 mb-3">
                  <Shield className="w-4 h-4 text-slate-300" />
                  <span className="text-slate-200 font-semibold text-sm">AI Confidence</span>
                </div>
                <p className="text-3xl font-bold text-white mb-2">{confidenceScore}%</p>
                <div className="w-full bg-[#06061A] rounded-full h-2 overflow-hidden mb-2">
                  <div
                    className="bg-gradient-to-r from-violet-500 to-purple-400 h-full rounded-full transition-all"
                    style={{ width: `${confidenceScore}%` }}
                  />
                </div>
                <p className="text-xs text-slate-400">
                  {confidenceScore >= 80 ? "Highly accurate analysis" : confidenceScore >= 60 ? "Moderate confidence" : "Use with caution"}
                </p>
              </div>
            )}
          </div>

          {/* Right Columns */}
          <div className="lg:col-span-2 space-y-4">
            {/* Calories & Health Score */}
            <div className="grid sm:grid-cols-2 gap-4">
              <div className="bg-gradient-to-br from-amber-500/15 to-orange-500/10 border border-amber-500/25 rounded-2xl p-5">
                <div className="flex items-center gap-2 mb-3">
                  <Flame className="w-5 h-5 text-amber-400" />
                  <p className="text-amber-200/80 font-semibold text-sm">Calories</p>
                </div>
                <p className="text-4xl font-bold text-amber-300" style={{ fontFamily: "Syne, sans-serif" }}>{totalCalories}</p>
                <p className="text-amber-400/60 text-xs mt-1">kcal per serving</p>
              </div>

              <div className="bg-[#0d0b22] border border-violet-500/20 rounded-2xl p-5">
                <div className="flex items-center gap-2 mb-3">
                  <Heart className="w-5 h-5 text-emerald-400" />
                  <p className="text-slate-300 font-semibold text-sm">Health Score</p>
                </div>
                <p className={`text-4xl font-bold ${getHealthColor(healthScore)}`} style={{ fontFamily: "Syne, sans-serif" }}>
                  {healthScore.toFixed(1)}
                </p>
                <p className="text-slate-500 text-xs mt-1">out of 10</p>
              </div>
            </div>

            {/* Macros */}
            <div className="bg-[#0d0b22] border border-violet-500/20 rounded-2xl p-5">
              <h3 className="text-lg font-bold text-white mb-5" style={{ fontFamily: "Syne, sans-serif" }}>Macronutrient Breakdown</h3>
              <div className="space-y-4 mb-5">
                {/* Protein */}
                <div>
                  <div className="flex justify-between items-center mb-1.5">
                    <div className="flex items-center gap-2">
                      <Zap className="w-4 h-4 text-violet-400" />
                      <span className="text-white font-semibold text-sm">Protein</span>
                    </div>
                    <span className="text-white font-bold text-sm">{Number(scan.protein) || 0}g</span>
                  </div>
                  <div className="w-full bg-[#06061A] rounded-full h-2.5 overflow-hidden">
                    <div className="bg-gradient-to-r from-violet-600 to-purple-500 h-full rounded-full transition-all" style={{ width: `${proteinPercent}%` }} />
                  </div>
                  <p className="text-xs text-slate-500 mt-1">{proteinPercent.toFixed(0)}% of macros</p>
                </div>
                {/* Carbs */}
                <div>
                  <div className="flex justify-between items-center mb-1.5">
                    <div className="flex items-center gap-2">
                      <Droplets className="w-4 h-4 text-cyan-400" />
                      <span className="text-white font-semibold text-sm">Carbs</span>
                    </div>
                    <span className="text-white font-bold text-sm">{Number(scan.carbs) || 0}g</span>
                  </div>
                  <div className="w-full bg-[#06061A] rounded-full h-2.5 overflow-hidden">
                    <div className="bg-gradient-to-r from-cyan-600 to-teal-500 h-full rounded-full transition-all" style={{ width: `${carbsPercent}%` }} />
                  </div>
                  <p className="text-xs text-slate-500 mt-1">{carbsPercent.toFixed(0)}% of macros</p>
                </div>
                {/* Fats */}
                <div>
                  <div className="flex justify-between items-center mb-1.5">
                    <div className="flex items-center gap-2">
                      <Flame className="w-4 h-4 text-amber-400" />
                      <span className="text-white font-semibold text-sm">Fats</span>
                    </div>
                    <span className="text-white font-bold text-sm">{Number(scan.fats) || 0}g</span>
                  </div>
                  <div className="w-full bg-[#06061A] rounded-full h-2.5 overflow-hidden">
                    <div className="bg-gradient-to-r from-amber-500 to-orange-500 h-full rounded-full transition-all" style={{ width: `${fatsPercent}%` }} />
                  </div>
                  <p className="text-xs text-slate-500 mt-1">{fatsPercent.toFixed(0)}% of macros</p>
                </div>
              </div>

              {/* Micro grid */}
              <div className="grid grid-cols-2 gap-3 bg-[#06061A]/60 rounded-xl p-4 border border-violet-500/10">
                {scan.fiber && <div><p className="text-slate-500 text-xs mb-0.5">Fiber</p><p className="text-white font-bold text-sm">{scan.fiber}g</p></div>}
                {scan.sugar && <div><p className="text-slate-500 text-xs mb-0.5">Sugar</p><p className="text-white font-bold text-sm">{scan.sugar}g</p></div>}
                {scan.sodium && <div><p className="text-slate-500 text-xs mb-0.5">Sodium</p><p className="text-white font-bold text-sm">{scan.sodium}mg</p></div>}
                {scan.cholesterol && <div><p className="text-slate-500 text-xs mb-0.5">Cholesterol</p><p className="text-white font-bold text-sm">{scan.cholesterol}mg</p></div>}
              </div>
            </div>
          </div>
        </div>

        {/* Vitamins & Minerals */}
        {((scan.vitamins as any) || (scan.minerals as any)) && (
          <div className="grid lg:grid-cols-2 gap-5 mb-5">
            {(scan.vitamins as any) && Array.isArray(scan.vitamins) && (scan.vitamins as any[]).length > 0 && (
              <div className="bg-[#0d0b22] border border-emerald-500/20 rounded-2xl p-5">
                <div className="flex items-center gap-2 mb-4">
                  <Leaf className="w-5 h-5 text-emerald-400" />
                  <h2 className="text-lg font-bold text-white" style={{ fontFamily: "Syne, sans-serif" }}>Vitamins</h2>
                </div>
                <div className="space-y-2.5">
                  {(scan.vitamins as any[]).map((v: any, i: number) => (
                    <div key={i} className="flex justify-between items-center bg-[#06061A]/50 rounded-xl px-3 py-2.5 border border-emerald-500/10">
                      <p className="text-emerald-300 font-semibold text-sm">{String(v.name)}</p>
                      <div className="flex items-center gap-2">
                        <span className="text-white font-bold text-sm">{String(v.amount)} {String(v.unit || "")}</span>
                        {v.dailyValue && <span className="text-xs text-emerald-400/70 bg-emerald-500/10 px-1.5 py-0.5 rounded">{String(v.dailyValue)}</span>}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {(scan.minerals as any) && Array.isArray(scan.minerals) && (scan.minerals as any[]).length > 0 && (
              <div className="bg-[#0d0b22] border border-cyan-500/20 rounded-2xl p-5">
                <div className="flex items-center gap-2 mb-4">
                  <Shield className="w-5 h-5 text-cyan-400" />
                  <h2 className="text-lg font-bold text-white" style={{ fontFamily: "Syne, sans-serif" }}>Minerals</h2>
                </div>
                <div className="space-y-2.5">
                  {(scan.minerals as any[]).map((m: any, i: number) => (
                    <div key={i} className="flex justify-between items-center bg-[#06061A]/50 rounded-xl px-3 py-2.5 border border-cyan-500/10">
                      <p className="text-cyan-300 font-semibold text-sm">{String(m.name)}</p>
                      <div className="flex items-center gap-2">
                        <span className="text-white font-bold text-sm">{String(m.amount)} {String(m.unit || "")}</span>
                        {m.dailyValue && <span className="text-xs text-cyan-400/70 bg-cyan-500/10 px-1.5 py-0.5 rounded">{String(m.dailyValue)}</span>}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        )}

        {/* Ingredients */}
        {scan.ingredients && Array.isArray(scan.ingredients) && scan.ingredients.length > 0 && (
          <div className="bg-[#0d0b22] border border-violet-500/20 rounded-2xl p-5 mb-5">
            <div className="flex items-center gap-2 mb-4">
              <Utensils className="w-5 h-5 text-violet-400" />
              <h2 className="text-lg font-bold text-white" style={{ fontFamily: "Syne, sans-serif" }}>Ingredients</h2>
            </div>
            <div className="grid sm:grid-cols-2 gap-2.5">
              {(scan.ingredients as any[]).map((ingredient: any, i: number) => (
                <div key={i} className="flex items-center gap-2.5 bg-[#06061A]/50 rounded-xl px-3 py-2.5 border border-violet-500/8">
                  <span className="text-emerald-400 font-bold text-base flex-shrink-0">✓</span>
                  <span className="text-slate-300 text-sm">{String(ingredient)}</span>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Allergens */}
        {scan.allergens && Array.isArray(scan.allergens) && scan.allergens.length > 0 && (
          <div className="bg-red-500/8 border border-red-500/25 rounded-2xl p-5 mb-5">
            <div className="flex items-start gap-3">
              <AlertCircle className="w-5 h-5 text-red-400 flex-shrink-0 mt-0.5" />
              <div>
                <h2 className="font-bold text-red-300 mb-3 text-lg" style={{ fontFamily: "Syne, sans-serif" }}>⚠️ Allergen Warnings</h2>
                <div className="flex flex-wrap gap-2">
                  {(scan.allergens as any[]).map((allergen: any, i: number) => (
                    <span key={i} className="px-3 py-1.5 bg-red-500/20 text-red-200 rounded-full text-sm font-semibold border border-red-500/35">
                      {String(allergen)}
                    </span>
                  ))}
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Health Benefits */}
        {scan.healthBenefits && Array.isArray(scan.healthBenefits) && (scan.healthBenefits as any[]).length > 0 && (
          <div className="bg-[#0d0b22] border border-emerald-500/20 rounded-2xl p-5 mb-5">
            <h2 className="font-bold text-white mb-4 text-lg" style={{ fontFamily: "Syne, sans-serif" }}>✨ Health Benefits</h2>
            <ul className="space-y-2">
              {(scan.healthBenefits as any[]).map((benefit: any, i: number) => (
                <li key={i} className="flex items-start gap-3 text-slate-300 text-sm">
                  <span className="text-emerald-400 font-bold mt-0.5 flex-shrink-0">→</span>
                  {String(benefit)}
                </li>
              ))}
            </ul>
          </div>
        )}

        {/* Recommendation */}
        {scan.healthRecommendation && (
          <div className="bg-[#0d0b22] border border-violet-500/20 rounded-2xl p-5 mb-5">
            <h2 className="font-bold text-white mb-3 text-lg" style={{ fontFamily: "Syne, sans-serif" }}>💡 Personalized Recommendation</h2>
            <p className="text-slate-300 text-sm leading-relaxed">{scan.healthRecommendation}</p>
          </div>
        )}

        {/* Disclaimer */}
        <div className="bg-amber-500/5 border-l-4 border-amber-500/50 rounded-r-xl rounded-l-none pl-4 pr-5 py-4 mb-6">
          <p className="text-amber-400 font-semibold text-sm mb-1">⚠️ Disclaimer</p>
          <p className="text-amber-400/60 text-xs leading-relaxed">
            ScanEat AI analysis is for informational purposes only. Always verify ingredients if you have allergies. Consult a healthcare professional for personalized dietary guidance.
          </p>
        </div>

        {/* Actions */}
        <div className="flex gap-3">
          <Button
            onClick={() => navigate("/history")}
            className="flex-1 bg-gradient-to-r from-violet-600 to-purple-600 hover:from-violet-500 hover:to-purple-500 text-white font-bold rounded-xl py-3 text-sm shadow-[0_0_20px_rgba(139,92,246,0.25)] transition-all"
          >
            Back to History
          </Button>
          <Button
            variant="outline"
            onClick={() => deleteMutation.mutate({ id: scanId })}
            disabled={deleteMutation.isPending}
            className="flex-1 border-red-500/30 bg-red-500/8 text-red-400 hover:bg-red-500/15 hover:border-red-500/50 rounded-xl py-3 text-sm transition-all"
          >
            <Trash2 className="w-4 h-4 mr-2" />
            {deleteMutation.isPending ? "Deleting..." : "Delete"}
          </Button>
        </div>
      </div>
    </div>
  );
}
