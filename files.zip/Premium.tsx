import { ArrowLeft, Zap, TrendingUp, Share2, Calendar, BarChart3, Crown, Check } from "lucide-react";
import { useLocation } from "wouter";

export default function Premium() {
  const [, navigate] = useLocation();

  const features = [
    { icon: <Zap className="w-6 h-6" />, title: "Advanced AI Analysis", description: "Ultra-precise food detection with 99% accuracy", color: "from-violet-600 to-purple-600", glow: "rgba(139,92,246,0.4)" },
    { icon: <TrendingUp className="w-6 h-6" />, title: "Personalized Insights", description: "Weekly nutrition reports and health trends", color: "from-cyan-500 to-teal-600", glow: "rgba(34,211,238,0.3)" },
    { icon: <Share2 className="w-6 h-6" />, title: "Social Sharing", description: "Share results with watermarked graphics", color: "from-emerald-500 to-teal-600", glow: "rgba(16,185,129,0.3)" },
    { icon: <Calendar className="w-6 h-6" />, title: "Meal Planning", description: "AI-powered meal suggestions & planning", color: "from-amber-500 to-orange-600", glow: "rgba(251,191,36,0.3)" },
    { icon: <BarChart3 className="w-6 h-6" />, title: "Nutrition Dashboard", description: "Comprehensive health analytics & tracking", color: "from-pink-500 to-rose-600", glow: "rgba(244,114,182,0.3)" },
  ];

  const benefits = ["Unlimited food scans", "Priority AI processing", "Detailed macro tracking", "Personalized diet plans", "Export nutrition data", "No ads ever"];

  return (
    <div className="min-h-screen pb-24 bg-[#06061A] relative">
      <div className="fixed top-0 left-1/2 -translate-x-1/2 w-[600px] h-64 bg-violet-700/10 rounded-full blur-3xl pointer-events-none" />
      <div className="fixed bottom-1/3 right-0 w-64 h-64 bg-amber-500/5 rounded-full blur-3xl pointer-events-none" />

      {/* Header */}
      <div className="sticky top-0 z-40 bg-[#06061A]/85 backdrop-blur-xl border-b border-violet-500/10">
        <div className="max-w-6xl mx-auto px-4 py-4 flex items-center gap-3">
          <button
            onClick={() => navigate("/")}
            className="w-9 h-9 rounded-xl bg-[#101027] border border-violet-500/15 flex items-center justify-center hover:border-violet-500/40 hover:bg-violet-500/10 transition-all text-slate-400 hover:text-violet-400"
          >
            <ArrowLeft className="w-4 h-4" />
          </button>
          <div className="flex items-center gap-2">
            <div className="w-7 h-7 rounded-lg bg-gradient-to-br from-amber-500 to-orange-600 flex items-center justify-center">
              <Crown className="w-4 h-4 text-white" />
            </div>
            <h1 className="text-xl font-bold text-white" style={{ fontFamily: "Syne, sans-serif" }}>Premium</h1>
          </div>
        </div>
      </div>

      <div className="max-w-2xl mx-auto px-4 py-8 relative z-10">

        {/* Hero */}
        <div className="rounded-2xl overflow-hidden relative mb-8 bg-gradient-to-br from-violet-700/70 via-purple-800/60 to-[#0a081e] border border-violet-500/25 p-8 text-center">
          <div className="absolute top-0 right-0 w-40 h-40 bg-violet-500/10 rounded-full blur-2xl -translate-y-1/3 translate-x-1/4 pointer-events-none" />
          <div className="absolute bottom-0 left-0 w-32 h-32 bg-amber-500/8 rounded-full blur-xl translate-y-1/3 -translate-x-1/4 pointer-events-none" />

          <div className="relative z-10">
            <div className="w-16 h-16 mx-auto mb-4 rounded-2xl bg-gradient-to-br from-amber-500 to-orange-600 flex items-center justify-center shadow-[0_0_30px_rgba(251,191,36,0.4)]">
              <Crown className="w-8 h-8 text-white" />
            </div>
            <p className="text-violet-300/70 text-xs font-semibold tracking-widest uppercase mb-2">Coming Soon</p>
            <h2 className="text-3xl font-bold text-white mb-3" style={{ fontFamily: "Syne, sans-serif" }}>
              Go Premium
            </h2>
            <p className="text-slate-300/80 text-sm leading-relaxed mb-6">
              Unlock the full power of AI nutrition tracking. Train smarter, eat better, recover faster.
            </p>
            <button className="px-8 py-3 bg-gradient-to-r from-violet-600 to-purple-600 hover:from-violet-500 hover:to-purple-500 text-white font-bold rounded-xl transition-all hover:scale-[1.02] shadow-[0_0_25px_rgba(139,92,246,0.35)] text-sm">
              Notify Me When Available
            </button>
          </div>
        </div>

        {/* What you get */}
        <div className="bg-[#0d0b22] border border-violet-500/15 rounded-2xl p-5 mb-6">
          <h3 className="text-base font-bold text-white mb-4" style={{ fontFamily: "Syne, sans-serif" }}>Everything included:</h3>
          <div className="grid grid-cols-2 gap-2.5">
            {benefits.map((b) => (
              <div key={b} className="flex items-center gap-2">
                <div className="w-5 h-5 rounded-full bg-emerald-500/20 border border-emerald-500/30 flex items-center justify-center flex-shrink-0">
                  <Check className="w-3 h-3 text-emerald-400" />
                </div>
                <span className="text-slate-300 text-xs">{b}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Feature cards */}
        <h3 className="text-base font-bold text-white mb-4" style={{ fontFamily: "Syne, sans-serif" }}>Premium Features</h3>
        <div className="space-y-3">
          {features.map((feature, i) => (
            <div
              key={i}
              className="rounded-2xl p-5 bg-[#0d0b22] border border-violet-500/10 hover:border-violet-500/25 transition-all group flex items-center gap-4"
            >
              <div
                className={`w-12 h-12 rounded-xl bg-gradient-to-br ${feature.color} flex items-center justify-center flex-shrink-0 text-white group-hover:shadow-[0_0_20px_var(--glow)] transition-all`}
                style={{ "--glow": feature.glow } as any}
              >
                {feature.icon}
              </div>
              <div>
                <h4 className="font-bold text-white text-sm mb-0.5" style={{ fontFamily: "Syne, sans-serif" }}>{feature.title}</h4>
                <p className="text-slate-500 text-xs">{feature.description}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
