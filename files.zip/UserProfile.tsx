import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";
import { ChevronLeft, LogOut, Moon, Sun, User, Settings, Dumbbell } from "lucide-react";
import { useLocation } from "wouter";
import { useTheme } from "@/contexts/ThemeContext";

export default function UserProfile() {
  const { user, logout } = useAuth();
  const { theme, toggleTheme, switchable } = useTheme();
  const [, setLocation] = useLocation();
  const [dietaryType, setDietaryType] = useState("vegetarian");
  const [allergies, setAllergies] = useState("");
  const [healthGoals, setHealthGoals] = useState("balanced");
  const [region, setRegion] = useState("");
  const [isSaving, setIsSaving] = useState(false);
  const [isLoggingOut, setIsLoggingOut] = useState(false);

  const logoutMutation = trpc.auth.logout.useMutation({
    onSuccess: () => { setIsLoggingOut(false); logout(); setLocation("/"); },
  });

  const handleLogout = async () => {
    setIsLoggingOut(true);
    try { await logoutMutation.mutateAsync(); }
    catch { setIsLoggingOut(false); toast.error("Failed to logout"); }
  };

  const handleSave = async () => {
    setIsSaving(true);
    try { toast.success("Profile updated successfully"); }
    catch { toast.error("Failed to update profile"); }
    finally { setIsSaving(false); }
  };

  const inputClass = "bg-[#0d0b22] border border-violet-500/20 text-white placeholder:text-slate-500 focus:border-violet-500/60 focus:ring-violet-500/20 rounded-xl";
  const labelClass = "text-slate-300 font-semibold text-sm mb-2 block";

  return (
    <div className="min-h-screen pb-24 bg-[#06061A] relative">
      <div className="fixed top-0 left-1/2 -translate-x-1/2 w-[500px] h-48 bg-violet-700/8 rounded-full blur-3xl pointer-events-none" />

      {/* Header */}
      <div className="sticky top-0 z-40 bg-[#06061A]/85 backdrop-blur-xl border-b border-violet-500/10">
        <div className="max-w-2xl mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <button
              onClick={() => setLocation("/")}
              className="w-9 h-9 rounded-xl bg-[#101027] border border-violet-500/15 flex items-center justify-center hover:border-violet-500/40 hover:bg-violet-500/10 transition-all text-slate-400 hover:text-violet-400"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>
            <div className="flex items-center gap-2">
              <div className="w-7 h-7 rounded-lg bg-gradient-to-br from-emerald-500 to-teal-600 flex items-center justify-center">
                <Settings className="w-4 h-4 text-white" />
              </div>
              <h1 className="text-xl font-bold text-white" style={{ fontFamily: "Syne, sans-serif" }}>Profile</h1>
            </div>
          </div>

          {switchable && toggleTheme && (
            <button
              onClick={toggleTheme}
              className="w-9 h-9 rounded-xl bg-[#101027] border border-violet-500/15 flex items-center justify-center hover:border-violet-500/40 hover:bg-violet-500/10 transition-all text-slate-400 hover:text-violet-400"
              title={`Switch to ${theme === "light" ? "dark" : "light"} mode`}
            >
              {theme === "light" ? <Moon className="w-4 h-4" /> : <Sun className="w-4 h-4" />}
            </button>
          )}
        </div>
      </div>

      <div className="max-w-2xl mx-auto px-4 py-6 relative z-10 space-y-4">

        {/* User Info Card */}
        <div className="bg-[#0d0b22] border border-violet-500/20 rounded-2xl overflow-hidden">
          {/* Card header accent */}
          <div className="h-1.5 bg-gradient-to-r from-violet-600 via-purple-500 to-emerald-500" />
          <div className="p-5">
            <div className="flex items-center gap-4 mb-5">
              <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-violet-600 to-purple-700 flex items-center justify-center shadow-[0_0_20px_rgba(139,92,246,0.3)]">
                <User className="w-7 h-7 text-white" />
              </div>
              <div>
                <h2 className="text-lg font-bold text-white" style={{ fontFamily: "Syne, sans-serif" }}>{user?.name || "User"}</h2>
                <p className="text-slate-400 text-sm">{user?.email || ""}</p>
              </div>
            </div>

            <div className="space-y-3">
              <div>
                <Label className={labelClass}>Name</Label>
                <Input value={user?.name || ""} disabled className={inputClass} />
              </div>
              <div>
                <Label className={labelClass}>Email</Label>
                <Input value={user?.email || ""} disabled className={inputClass} />
              </div>
            </div>
          </div>
        </div>

        {/* Preferences Card */}
        <div className="bg-[#0d0b22] border border-violet-500/20 rounded-2xl overflow-hidden">
          <div className="h-1.5 bg-gradient-to-r from-emerald-500 via-teal-500 to-cyan-500" />
          <div className="p-5">
            <div className="flex items-center gap-2 mb-5">
              <div className="w-7 h-7 rounded-lg bg-gradient-to-br from-emerald-500 to-teal-600 flex items-center justify-center">
                <Dumbbell className="w-4 h-4 text-white" />
              </div>
              <h3 className="font-bold text-white" style={{ fontFamily: "Syne, sans-serif" }}>Dietary & Fitness Preferences</h3>
            </div>

            <div className="space-y-4">
              <div>
                <Label className={labelClass}>Dietary Type</Label>
                <Select value={dietaryType} onValueChange={setDietaryType}>
                  <SelectTrigger className={inputClass}>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="bg-[#0d0b22] border border-violet-500/25">
                    <SelectItem value="vegan">🌱 Vegan</SelectItem>
                    <SelectItem value="vegetarian">🥬 Vegetarian</SelectItem>
                    <SelectItem value="non-vegetarian">🍗 Non-Vegetarian</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label className={labelClass}>Allergies</Label>
                <Input
                  placeholder="e.g., peanuts, shellfish, dairy"
                  value={allergies}
                  onChange={(e) => setAllergies(e.target.value)}
                  className={inputClass}
                />
              </div>

              <div>
                <Label className={labelClass}>Health & Fitness Goals</Label>
                <Select value={healthGoals} onValueChange={setHealthGoals}>
                  <SelectTrigger className={inputClass}>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="bg-[#0d0b22] border border-violet-500/25">
                    <SelectItem value="weight-loss">⚡ Weight Loss</SelectItem>
                    <SelectItem value="muscle-gain">💪 Muscle Gain</SelectItem>
                    <SelectItem value="balanced">⚖️ Balanced Diet</SelectItem>
                    <SelectItem value="diabetes">🩺 Diabetes Management</SelectItem>
                    <SelectItem value="fitness">🏋️ General Fitness</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label className={labelClass}>Region</Label>
                <Input
                  placeholder="e.g., India, USA, UK"
                  value={region}
                  onChange={(e) => setRegion(e.target.value)}
                  className={inputClass}
                />
              </div>
            </div>
          </div>
        </div>

        {/* Actions */}
        <div className="space-y-3">
          <div className="flex gap-3">
            <Button
              onClick={() => setLocation("/")}
              variant="outline"
              className="flex-1 border-violet-500/25 bg-transparent text-slate-300 hover:bg-violet-500/10 hover:border-violet-500/45 hover:text-white rounded-xl py-3 text-sm transition-all"
            >
              Cancel
            </Button>
            <Button
              onClick={handleSave}
              disabled={isSaving}
              className="flex-1 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-bold rounded-xl py-3 text-sm shadow-[0_0_20px_rgba(16,185,129,0.2)] transition-all disabled:opacity-50"
            >
              {isSaving ? "Saving..." : "Save Preferences"}
            </Button>
          </div>

          <Button
            onClick={handleLogout}
            disabled={isLoggingOut}
            className="w-full bg-red-500/10 border border-red-500/25 text-red-400 hover:bg-red-500/20 hover:border-red-500/45 hover:text-red-300 font-bold rounded-xl py-3 text-sm transition-all disabled:opacity-50 flex items-center justify-center gap-2"
          >
            <LogOut className="w-4 h-4" />
            {isLoggingOut ? "Logging out..." : "Sign Out"}
          </Button>
        </div>
      </div>
    </div>
  );
}
